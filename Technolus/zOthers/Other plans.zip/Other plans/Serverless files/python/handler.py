import json

def route(event,context):
    """ EXPECTED MESSAGE FORMAT
    { 'target':['cloud','optional-others'],
        'command':'',
        'data':{}
    }
    """

    """
    check the header on the message and route to html, websocket or other...
    for now I'll keep the html only, in order to mirror the message for debugging.
    """
    
    events = '<pre>' + json.dumps(event, indent=4, sort_keys=False) + '</pre>'
    contexts = ''

    html = f"""
            <html>
                <head>
                    <meta name='viewport' content="width=device-width, initial-scale=1" />
                    <title>test</title>
                    <style>
                        body{{
                        font-size: 14px;
                        line-height: normal;
                        font-family: "Helvetica Neue", Roboto, Arial, sans-serif;
                        color: #444444;
                        background-color: white;
                        }}
                        h1{{
                            color: #73757d;
                        }}
                        .spacer{{
                            height: 1em; 
                        }}
                        .json{{
                            color: blue;
                        }}
                    </style>
                </head>
                <body>
                    <h1>test</h1>
                    <div class="json">{events}</div>
                    <div class="spacer"></div>
                </body>
            </html>
            """

    response = {
        "statusCode": 200,
            "headers": {
                'Content-Type': 'text/html',
            },
            "body": html
    }
    return response


def main(event, context):
    response = route(event,context)
    return response

    # # Use this code if you don't use the http event with the LAMBDA-PROXY
    # # integration
    # """
    # return {
    #     "message": "Go Serverless v1.0! Your function executed successfully!",
    #     "event": event
    # }
    # """

# if __name__ == "__main__":
#     print(main("hi","hello"))


