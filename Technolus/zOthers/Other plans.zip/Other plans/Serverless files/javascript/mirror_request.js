export const hello = async (event, context) => {

  data = {
    'TIME':                             event.requestContext.requestTime,
    'IP':                               event.requestContext.identity.sourceIp,
    'PREFIX':                           event.requestContext.domainPrefix,
    'SUFIX':                            event.requestContext.path,
    'QUERY':                            event.queryStringParameters,
    'AGENT':                            event.requestContext.identity.userAgent,
    'LANGUAGE':                         event.headers.accept-language,
    'IS_LOCAL':                         False
  }

title = event['requestContext']['domainPrefix'].title()


  return {
    statusCode: 200,
    headers: {
        'Content-Type': 'text/html',
        "Access-Control-Allow-Origin": "*"
    },
    body: `
            <html>
                <head>
                    <meta name='viewport' content="width=device-width, initial-scale=1" />
                    <title>${title}</title>
                    <style>
                        body{{
                        font-size: 14px;
                        line-height: normal;
                        font-family: "Helvetica Neue", Roboto, Arial, sans-serif;
                        color: #444444;
                        background-color: white;
                        }}
                        h1{{
                            color: #73757d;
                        }}
                        .spacer{{
                            height: 1em; 
                        }}
                        .json{{
                            color: blue;
                        }}
                    </style>
                </head>
                <body>
                    <h1>${title}</h1>
                    <div class="json">${datas}</div>
                    <div class="spacer"></div>
                </body>
            </html>
          `
  };
};

